# Alessandro Nutrition v2.5

Revisione completa del flusso di inserimento e del calendario.

Novità principali:
- configurazione iniziale con domande di base e campo note/altro;
- profilo e preferenze modificabili dalle Impostazioni;
- selettore grafico Android per data e ora;
- scorciatoie Oggi, Domani, Adesso e orari rapidi;
- categorie evento con icona dedicata;
- ricorrenze rapide e personalizzate con giorni della settimana e data di fine;
- riepilogo leggibile della ricorrenza prima del salvataggio;
- promemoria rapidi 10/30/60 minuti e 1 giorno, più valore personalizzato;
- calendario Settimana/Mese/Anno con navigazione e mini-calendari annuali;
- eventi del calendario con icona della categoria.

Mantiene le correzioni v2.4.1 su piano 4 settimane, allenamenti, reminder e widget.
